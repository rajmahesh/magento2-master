<?php

namespace Infobeans\Salesorder\Observer;
use Magento\Catalog\Model\Product;

use Magento\Framework\Event\Observer;

use Magento\Framework\Event\ObserverInterface;
class MyObserver implements ObserverInterface{

    public function execute(\Magento\Framework\Event\Observer $observer){
        $order = $observer->getEvent()->getOrder();
//        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/test.log');
//        $logger = new \Zend\Log\Logger();
//        $logger->addWriter($writer);
//        $logger->info('Harish Jangid : '.$order->getIncrementId());
        $productType = array();
        foreach ($order->getAllVisibleItems() as $item) {
            if(!in_array($item->getProductType(), $productType)){
                $productType []=$item->getProductType();
            }
        }
//        $logger->info('Harish Jangid : '.print_r($productType, true));
        $order->setProductTypes(implode(", ", $productType));
//        $order->save();
    }
}
